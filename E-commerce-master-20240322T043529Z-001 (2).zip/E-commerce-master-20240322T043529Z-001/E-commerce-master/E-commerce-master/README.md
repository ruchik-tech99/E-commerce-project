# E-commerce 
<h3>Introduction</h3>
<p>An ecommerce website project using HTML CSS JavaScript and firebase database.</p>

<h3>About</h3>
<p>This isn't an original working website, can say it's a demo of an Ecommerce website with functionalities like User sign-up and Login, Products list fetched from database, working add to cart, Account section for user's info, place an order, cancel an order, payment method is just an example, it isn't working.</p>

<h3>Some information</h3>
<p>Other functionalities like validation and authorization are all working fine. 
Will be updating and modifying this project. New features and designing can be implemented in future.</p> 
